#include "q1.h"
//#include "q1.cpp"
#include <iostream>
using namespace std;

Fraction::Fraction()
{
	num=0;
	deno=1;
}

Fraction::Fraction(int n)
{
	num=n;
	deno=1;
}

Fraction::Fraction(int n, int d)
{
	num=n;
	deno=d;
}

Fraction::Fraction(Fraction &F)
{
	this->num=F.num;
	this->deno=F.deno;
}

int Fraction::getnum()const
{
	return num;
}

int Fraction::getdeno()const
{
	return deno;
}

void Fraction::setdeno(int d)
{
	deno=d;
}

void Fraction::setnum(int n)
{
	num=n;
}

Fraction& Fraction::operator+(const Fraction &p)
{
	Fraction add;
	add.num=(num*p.deno)+(p.num*deno);
	add.deno=deno*p.deno;
	return add;	
}

Fraction& Fraction::operator-(const Fraction &p)
{
	Fraction sub;
	sub.num=(num*p.deno)-(p.num*deno);
	sub.deno=deno*p.deno;
	return sub;	
}

Fraction& Fraction::operator*(const Fraction &p)
{
	Fraction mul;
	mul.num=(num*p.deno)*(p.num*deno);
	mul.deno=deno*p.deno;
	return mul;	
}

Fraction& Fraction::operator/(const Fraction &p)
{
	Fraction div;
	div.num=(num*p.deno);
	div.deno=deno*p.deno;
	return div;	
}

bool Fraction::operator==(const Fraction &f1)
{
	/*Fraction ass;	
	if(ass.num==f1.num and ass.deno==f1.deno)
	cout<<"Fractions are equal"<<endl;
	else
	cout<<"Fraction doesn't matched"<<endl;
	 return ass;
	*/

	if(*this!=f1)
	return false;
	else
	return true;
} 

bool Fraction::operator!=(const Fraction &f1)
{
	/*Fraction net;

	if(net.num!=f1.num or net.deno!=f1.deno)
	cout<<"Fractions are not equal"<<endl;
	 return net;*/
	if(*this>f1 or *this<f1)
	return true;
	else
	return false;
} 

bool Fraction::operator>(const Fraction& f1)
{
	/*if(f1>f2)
	cout<<"Fraction "<<f1<<" is greater than "<<f2<<"  "<<endl;
	else
	cout<<"Fraction "<<f1<<" is not greater than "<<f2<<"  "<<endl;
	return (f1>f2);*/
	int num_current;
	int f1_num;
	int common_deno;
  	num_current=num*f1.deno; 
  	f1_num=f1.num*deno;
  	common_deno=deno*f1.deno;
  	if ((num_current-f1_num)*common_deno<=0) 
	return false;
	else
  	return true;
} 


bool Fraction::operator<(const Fraction& f1)
{
	/*if(f1<f2)
	cout<<"Fraction "<<f1<<" is less than "<<f2<<"  "<<endl;
	else
	cout<<"Fraction "<<f1<<" is not lesser than "<<f2<<"  "<<endl;
	return (f1<f2);*/
	 int num_current,f1_num,common_deno;
	 num_current=num*f1.deno;
	 f1_num=f1.num*deno;
	 common_deno=deno*f1.deno;
	 if ((num_current-f1_num)*common_deno<0) 
	 return true;
	 else
	 return false;
} 

bool Fraction::operator<=(const Fraction &f1)
{
	if(*this>f1)
	return false;
	else
	return true;
}

bool Fraction::operator>=(const Fraction &f1)
{
	if(*this<f1)
	return false;
	else
	return true;
}

void operator++(Fraction &f1)
{
	f1.num=(f1.num*f1.deno)+1;
	f1.deno=f1.deno*f1.deno;		
}

void operator--(Fraction &f1)
{
	f1.num=(f1.num*f1.deno)-1;
	f1.deno=f1.deno*f1.deno;		

}


Fraction& Fraction::operator+=(Fraction &p )
{
	this->num=(this->num*this->deno)+p.num;
	this->deno=this->deno*p.deno;	
	return *this;
}

Fraction& Fraction::operator-=(Fraction &p )
{
	this->num=(this->num*this->deno)-p.num;
	this->deno=this->deno*p.deno;	
	return *this;
}

Fraction& Fraction::operator*=(Fraction &p )
{
	this->num=(this->num*this->deno)*p.num;
	this->deno=this->deno*p.deno;	
	return *this;
}

Fraction& Fraction::operator->()
{
	return *this;
}

Fraction& Fraction::operator()(int numerator,int denominator)
{
	num=numerator;
	deno=denominator;
	return *this;
}

Fraction& Fraction::operator&(Fraction obj)
{
	return obj;
}

ostream& operator<<(ostream& out,Fraction& f) 
{ 
   out<<f.num<<'/'<<f.deno; 
   return out; 
} 

istream& operator>>(istream& in,Fraction& f) 
{ 
   in>>f.num;
   in>>f.deno; 
   return in; 
} 


void Fraction::display()
{
 
  int n=num;
  int d=deno;
   if(n>d)
   {
   for(int counter=2;counter<d;counter++)
     {
           while(n%counter==0 & d%counter==0)
           {
      	     n=(n/counter);
      	     d=(d/counter);
           }
      }
   }
   else if(d>n)
   {
   for(int counter=2;counter<n;counter++)
     {
           while(n%counter==0 & d%counter==0)
           {
          	 n=(n/counter);
          	 d=(d/counter);
           }
      }
   }

	   cout<<n<<"/"<<d;
}

