#ifndef INCLUDE_Q1_H
#define INCLUDE_Q1_H
#include <iostream>
using namespace std;

class Fraction
{
  private:
        int num;
	int deno;
  public:                                                     
	Fraction();
	Fraction(int);
	Fraction(int,int);
	Fraction(Fraction &);
	int getnum()const;
	int getdeno()const;
	void setnum(int n);
	void setdeno(int d);
	void display();
	Fraction& operator+(const Fraction &);
	Fraction& operator-(const Fraction &);
	Fraction& operator*(const Fraction &);
	Fraction& operator/(const Fraction &);
	Fraction& operator+=(Fraction &);
	Fraction& operator-=(Fraction &);
	Fraction& operator*=(Fraction &);
	Fraction& operator/=(Fraction &);
	
	bool operator==(const Fraction &);
	bool operator!=(const Fraction &);
	bool operator<(const Fraction &f1);
	bool operator>(const Fraction &);
	bool operator<=(const Fraction &);
	bool operator>=(const Fraction &);
	
	Fraction& operator[](Fraction &);
		
	friend void operator++(Fraction &);
	friend void operator--(Fraction &);
	Fraction& operator&&(Fraction &);
	Fraction& operator||(Fraction &);
	Fraction& operator&(Fraction );
	Fraction& operator->();
	Fraction& operator()(int ,int);
	Fraction& operator->*(Fraction &);

	friend ostream& operator<<(ostream& , Fraction& );
	friend istream& operator>>(istream& ,Fraction& );

};
#endif
