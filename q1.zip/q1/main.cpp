#include <iostream>
#include "q1.h"
using namespace std;

int main()
{

   Fraction f1(2,4);
   Fraction f2(4,8);
   Fraction f3;
   cout<<"Adding First and second Fractions we get: "<<endl;
   f3=f1+f2;
   f3.display();
   cout<<endl;
   
   cout<<"Subtracting First and second Fractions we get: "<<endl;
   f3=f1-f2;
   f3.display();
   cout<<endl;

   cout<<"Adding first fraction in the second one "<<endl;
   f2+=f1;
   cout<<f2;
   cout<<endl;

   cout<<"SUbtracting first fraction in the third one "<<endl;
   f3-=f1;
   cout<<f3;
   cout<<endl;

   cout<<"Copying First fraction in F3"<<endl;
   f3=f1;
   cout<<f3;
   cout<<endl;
 
   cout<<"Comparing two fractions if they are qual or not "<<endl;
   if(f2==f1)
   cout<<"Fractions are equal"<<endl;
   cout<<endl;

   cout<<"Calculating if one fraction is greater than the other"<<endl;
   if(f1>f2)
   cout<<"First fraction is greater then the other"<<endl;
   cout<<endl;
  
   if(f2<=f3)
   cout<<"2nd fraction is less then equal to the third fraction"<<endl;
   cout<<endl;

   cout<<"Incrementing the value in fraction"<<endl;
   ++f1;
   cout<<f1;
   cout<<endl;

   cout<<"Returning the adress of your Fraction"<<endl;
   cout<<&f1;  
   cout<<endl;
} 
