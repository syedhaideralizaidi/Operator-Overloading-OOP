#ifndef INCLUDE_Q5_H
#define INCLUDE_Q5_H
#include <iostream>
using namespace std;


class Array
{
	private:
		int size;
		int *ptr;
	public:
		Array();
		Array(int);
		Array(int *,int);
		Array(const Array &);
		int getSize();
		void setSize(int);
		int& operator[](int);
		int & operator[](int)const;
		const Array& operator=(const Array &);
		Array& operator+(const Array &);
		Array& operator-(const Array &);
		Array operator++();
		Array operator++(int);
		Array operator--(int);
		bool operator==(const Array &)const;
		bool operator!();
		void operator+=(const Array &);
	 	void operator-=(const Array &);
		int operator()(int idx,int val);
		~Array();
		friend ostream& operator<<(ostream & ,const Array &);
		friend istream& operator>>(istream & ,Array &);

};

#endif
