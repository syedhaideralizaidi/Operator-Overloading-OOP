#include "q5.h"
#include <iostream>
using namespace std;

Array::Array()
{
	size=0;
	for(int i=0;i<size;i++)
	{
	  ptr[i]=0;
	}

}

Array::Array(int *ptr,int s)
{
	 size = s; 
    	ptr = NULL; 
    	if (s!= 0) 
	{ 
          ptr = new int[s]; 
          for (int i=0; i<s; i++) 
            ptr[i] = 0; 
	}

}

Array::Array(int s)
{ 
	if(s>0)
	size=s;
	else
	size=8;
        ptr = new int [size];
        for (int i=0;i<size;i++)
             ptr[i] =0; 
}

Array::Array (const Array &arr)
{
         ptr = new int [size];
         for (int i=0; i<size;i++)
             ptr [i] =arr.ptr [i];
}

int Array::getSize()
{
	return size;
}

void Array::setSize(int s)
{
	size=s;
}

const Array& Array::operator=(const Array &obj)
{
	 if(&obj!=this)
	 {
            if(size != obj.size)
 	    {
                   delete [] ptr; 
                   size = obj.size; 
                   ptr = new int [ size ]; 
            }
         }
         
	for(int i=0; i<size; i++)
                 ptr[i] = obj.ptr[i];
         return *this;  

}

Array& Array::operator+(const Array &obj)
{
	Array a(size);
	if(this->size==obj.size)
	{
	   for(int i=0;i<size;i++)
	    {
		a.ptr[i]=this->ptr[i]+obj.ptr[i];
	    }
	}
	return a;
}
void Array::operator+=(const Array &obj)
{
	if(this->size==obj.size)
	{
		for(int i=0;i<size;i++)
		{
			this->ptr[i]=this->ptr[i]+obj.ptr[i];
		}
	}
}

Array& Array::operator-(const Array &obj)
{
	Array a(size);
	if(this->size==obj.size)
	{
	    for(int i=0;i<size;i++)
	    {
		a.ptr[i]=this->ptr[i]-obj.ptr[i];
	    }
	}
	return a;
}

void Array::operator-=(const Array &obj)
{
	if(this->size==obj.size)
	{
		for(int i=0;i<size;i++)
		{
			this->ptr[i]=this->ptr[i]-obj.ptr[i];
		}
	}
}


int& Array::operator[](int index)const
{
         if(index>=0 and index<size)
            return ptr[index];
	else if(index>size)
	cout<<"Index out of bound"<<endl;      
}

int& Array::operator[](int index)
{
         if(index>=0 and index<size)
            return ptr[index];      
	else if(index>size)
	cout<<"Index out of bound"<<endl;      

}

bool Array::operator==(const Array &obj)const
{
         if (size!=obj.size)
            return false;
         for ( int i=0; i<size; i++)
	{
             if (ptr[i]!= obj.ptr[i])
                return false;
         }
         return true;
}

int Array::operator()(int idx,int value)
{
	this->ptr[idx]=0;
	if(this->ptr[idx]=0)
	return 1;
	else
	return -1;
}

Array Array::operator++(int val)
{
	for(int i=0;i<this->size;i++)
	{
		this->ptr[i]=this->ptr[i]+val;
	}		
}

Array Array::operator++()
{
	for(int i=0;i<this->size;i++)
	{
		this->ptr[i]=this->ptr[i]+1;
	}		
}


Array Array::operator--(int val)
{
	for(int i=0;i<this->size;i++)
	{
		this->ptr[i]=this->ptr[i]-1;
	}		
}

bool Array::operator!()
{
	if(this->ptr==NULL)
	return true;
	else
	return false;
}
Array::~Array()
{
         delete[]ptr;
}

ostream& operator<<(ostream& output, const Array &obj)
{
	int i=0;         
	for (i=0;i<obj.size;i++)
             {
		output<<"        "<<obj.ptr[i];
		if((i+1)%4==0)					//4 numbers per row 
		output<<endl;
	     }
		if((i+1)%4!=0)
		output<<endl;
	return output;	 
}

istream& operator>>(istream &input,Array &obj)
{
         for (int i=0;i<obj.size;i++)
             input>>obj.ptr[i];
	return input;
}
