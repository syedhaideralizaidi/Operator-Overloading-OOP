#include <iostream>
#include "q5.h"
using namespace std;

int main()
{
	Array arr(4);
	Array arr2(5);
	
	cout<<"Size of this array is : "<<endl;
	cout<<arr.getSize();
	cout<<"Array after initialization :\n"<<arr;
	
	cout<<"Size of this array is : "<<endl;
	cout<<arr2.getSize();
	cout<<"Array after initialization :\n"<<arr2;
	
	cout<<"Enter 15 values : "<<endl;
	cin>>arr;
	cin>>arr2;
	
	cout<<endl<<endl;
	cout<<"After input the values are : "<<endl;
	cout<<"Array 1 is : "<<arr;
	cout<<"Array 2 is : "<<arr2;

	if(arr==arr2)
	cout<<"Array 1 is equal to array 2"<<endl;
	
	Array arr3(arr);

	cout<<"Size of 3rd array is "<<endl;
	cout<<arr3.getSize();
	cout<<"Array after initialization :\n"<<arr3;

	cout<<"Assigning second array to first array "<<endl;
	arr=arr2;
	cout<<"Array 1 is "<<arr<<endl;
	cout<<"Array 2 is "<<arr2<<endl;

	cout<<"Checking if two arrays are equal "<<endl;
	if(arr==arr2)
	cout<<"Arrays are equal"<<endl;

	//using subscript array
	cout<<endl<<endl;
	cout<<"arr[3] : "<<arr[3];

return 0;
	
}
