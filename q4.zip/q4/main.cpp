
#include "q4.h"
using namespace std;
int main()
{
     Polynomial P1, P2, P3;
     
	cout<<"Enter the polynomial"<<endl;	
	cin>>P1;
	cout<<"Enter the polynomial"<<endl;
	cin>>P2;
	
     	cout<<P1<<endl;     
	cout<<P2<<endl;

	cout<<"Using Copy constructor by copying P3 in P1"<<endl;
	P1=P3;

     	if(P1==P2)
        cout <<"These two Polynomials are same \n";

	P3 = P1 + P2;
	cout <<"Addition of two Polynomial is \n";      
	cout<<P3;
		
	cout<<"Adding 2nd Polynomial in 3rd Polynomial"<<endl;  	     
	P3+=P2;
	cout<<P3;

	P3 = P1-P2;
	cout <<"Subtraction of two polynomial is \n";   
	cout<<P3;
  	
	return 0;    
}
