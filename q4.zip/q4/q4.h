#ifndef INCLUDE_Q4_H
#define INCLUDE_Q4_H
#include <iostream>
using namespace std;

class Polynomial
{
	private:
		int degree;
		int coeff[8];
	public:
		Polynomial();
		Polynomial(int,int[]);
		Polynomial(const Polynomial &);
		int get_degree();
		void set_degree(int);
		void set_coeff();
		int get_coeff();
		Polynomial& operator+(const Polynomial &);
		Polynomial& operator-(const Polynomial &);	
		Polynomial& operator=(const Polynomial &);
		Polynomial& operator+=(const Polynomial &);
		Polynomial& operator-=(const Polynomial &);
		bool operator==(const Polynomial &); 
		friend ostream& operator<<(ostream &,const Polynomial &);
		friend istream& operator>>(istream &,Polynomial &);
		~Polynomial();
};

#endif
