#include "q4.h"
#include <iostream>
using namespace std;


Polynomial::Polynomial()
{
	degree=0;
	coeff[8]=0;
}

Polynomial::Polynomial(int d,int c[])
{
	if(d>=0 and d<=8)
	{
		degree=d;
		
	       for(int i=0;i<=degree;i++)
	       coeff[i]=c[i]; 
		for(int i=degree+1;i<8;i++)
		coeff[i]=0;
	}
	else
	{
		degree=0;
		for(int i=0;i<=8;i++)
		{
			coeff[i]=0;
		}
	}
}

Polynomial::Polynomial(const Polynomial &p)
{
	degree=p.degree;
	for(int i=0;i<=degree;i++)
	{
		coeff[i]=p.coeff[i];
	}

}

int Polynomial::get_degree()
{
	return degree;
}

void Polynomial::set_degree(int d)
{
	degree=d;
}

int Polynomial::get_coeff()
{ 
	int d=0;
    if( d>=0 and d<=degree)
	return coeff[d]; 
	else
	     return 0; 
}
 
void Polynomial::set_coeff()
{ 
 	for (int i=0;i<coeff[i];i++)  
    	{  
		cout<<"Enter coefficient for x^"<<i<<" : ";  
		cin>>coeff[i];     
	} 
}

Polynomial& Polynomial::operator+(const Polynomial &p)
{
	int c1[8];
	int d1;
	if(degree<p.degree)
	d1=degree;
	else
	d1=p.degree;

	for(int i=0;i>=d1;i--)
	{
		c1[i]=coeff[i]+p.coeff[i];
	}
	Polynomial p1(d1,c1);
	return p1;
}
	
Polynomial& Polynomial::operator-(const Polynomial &p)
{
	int c1[8];
	int d1;
	if(degree<p.degree)
	d1=degree;
	else
	d1=p.degree;

	for(int i=0;i>=d1;i--)
	{
		c1[i]=coeff[i]-p.coeff[i];
	}
	Polynomial p1(d1,c1);
	return p1;
}

Polynomial& Polynomial::operator=(const Polynomial &obj)
{
	degree=obj.degree;
	for(int i=0;i<=degree;i++)
	      coeff[i]=obj.coeff[i];  
         return *this;  
}

Polynomial& Polynomial::operator+=(const Polynomial &obj) 
{
     Polynomial  P;
     for(int i=0;i<=degree;i++)
	{
           P.coeff[i]=coeff[i]+obj.coeff[i] ;
           coeff[i]=P.coeff[i];
     	}
     return P;     
}

Polynomial& Polynomial::operator-=(const Polynomial &obj) 
{
     Polynomial  P;
     for(int i=0;i<=degree; i++)
	{
           P.coeff[i] = coeff[i]- obj.coeff[i] ;
           coeff[i] = P.coeff[i];
     	}
     return P;     
}


bool Polynomial::operator==(const Polynomial &obj)
{
         if (this->degree!=obj.degree)
            return false;
         for(int i=0;i<obj.degree;i++)
	 {
             if (this->coeff[i]!= obj.coeff[i])
                return false;
         }
         return true;
}



Polynomial::~Polynomial()		
{
	delete coeff;
}


ostream& operator<<(ostream& output, const Polynomial &obj)
{
	for (int i=0;i<obj.degree;i++)
	{       
		if (obj.coeff[i]!=0) 
		{         
			output<<obj.coeff[i]<<"x^" <<i<< " ";
		}
		output<<endl;
	}
	return output;
}

istream& operator>>(istream& input,Polynomial &obj)
{
	for (int i=0;i<obj.get_degree();i++)
	{       
		if (obj.coeff[i]!=0) 
		{         
			input>>obj.coeff[i];
		}
	}
	return input;
}



