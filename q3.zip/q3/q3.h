#ifndef INCLUDE_Q3_H
#define INCLUDE_Q3_H
#include <iostream>
using namespace std;

class Matrix
{
	private:
		int row;
		int col;
		int **array;

	public:
		Matrix();
		Matrix(int,int);
		Matrix(const Matrix &);
		int get_row();
		int get_col();
		void set_row(int);
		void set_col(int);
		void setValue(int , int , int);
		int operator()(int &,int &,int);			
		int operator()(int &,int &,int)const;
		Matrix& operator=(const Matrix &);

		bool operator==(const Matrix & );
	 	Matrix& operator+(const Matrix &);
		Matrix& operator-(const Matrix &);
		Matrix& operator*(const Matrix &);
		
		Matrix& operator++(int);
		void operator+=(const Matrix &);
		void operator-=(const Matrix &);
		~Matrix();
		int SetValue(int &r,int &c,int val);
		int getValue(int,int);
		friend ostream& operator<<(ostream &input,const Matrix &);
		friend istream& operator>>(istream &output,const Matrix&);

};



#endif 
