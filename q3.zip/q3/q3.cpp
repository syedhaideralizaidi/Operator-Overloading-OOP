#include "q3.h"
#include <iostream>
using namespace std;

Matrix::Matrix(int r,int c)
{
	row=r;
	col=c;
	array = new int*[row];              

	for (int i=0; i<row; i++)
	{
	      array[i] = new int[col];        
	}

	for (int i=0; i<row; i++)
	{
		for (int j=0; j<col; j++)
		{
			array[i][j] = 0;          
		}
	}
}

Matrix::Matrix(const Matrix &m1)
{
	row = m1.row;
	col = m1.col;
	array = new int*[row];
	for (int i=0; i<row; i++)
	{
	     array[i] = new int[col];
	}
	for (int i=0; i<row; i++)
	{
		for (int j=0; j<col; j++)
		{
			array[i][j] = m1.array[i][j];
		}
	}
}

int Matrix::get_row()
{
	return row;
}

int Matrix::get_col()
{
	return col;
}

void Matrix::set_row(int r)
{
	row=r;
}

void Matrix::set_col(int c)
{
	col=c;
}

Matrix& Matrix::operator=(const Matrix &m1)
{
	Matrix m2(row,col);
	for(int i=0;i<row;i++)
	{
	    for(int j=0;j<col;j++)
	    {
		m2.array[i][j]=m1.array[i][j];	
	    }
		return m2;
	}
}

Matrix& Matrix::operator+(const Matrix &m1)
{
    if (row==m1.row or col==m1.col)
    {
	Matrix m2(row,col);

	for (int i=0; i<row; i++)
	{
		for (int j=0; j<col; j++)
		{
			m2.array[i][j]=array[i][j]+m1.array[i][j];
		}
	}
	return m2;
    }
    	    else
	{	
		cout<<"Condition are not statisfied for Matrix Addition"<<endl;
		return (*this);
	}	
}

void Matrix::operator+=(const Matrix &m)
{
	if (this->row==m.row or this->col==m.col)
    {
	for (int i=0; i<row; i++)
	{
		for (int j=0; j<col; j++)
		{
			this->array[i][j]=m.array[i][j]+this->array[i][j];
		}
	}
    }
	else
	{	
		cout<<"Condition are not statisfied for Matrix Addition"<<endl;
	}
}


Matrix& Matrix::operator-(const Matrix &m1)
{
    if (row==m1.row or col==m1.col)
    {
	Matrix m2(row,col);

	for (int i=0; i<row; i++)
	{
		for (int j=0; j<col; j++)
		{
			m2.array[i][j]=array[i][j]-m1.array[i][j];
		}
	}
	return m2;
    }
    	    else
	{	
		cout<<"Condition are not statisfied for Matrix Subtraction"<<endl;
		return (*this);
	}	
}

void Matrix::operator-=(const Matrix &m)
{
	if (this->row==m.row or this->col==m.col)
    {
	for (int i=0; i<row; i++)
	{
		for (int j=0; j<col; j++)
		{
			this->array[i][j]=this->array[i][j]-m.array[i][j];
		}
	}
    }
	else
	{	
		cout<<"Condition are not statisfied for Matrix Subtraction"<<endl;
	}
}


Matrix& Matrix::operator*(const Matrix &m1)
{
	Matrix m2(row,col);
	
	for (int i=0; i<row; i++)
	{  
		for (int j=0; j<col; j++)
		{  
			for(int k=0; k<col;k++)
            		{
                		m2.array[i][j]+=array[i][k]*m1.array[k][j];
            		}
		}
	}
	return m2;
}

Matrix& Matrix::operator++(int x)
{
	for(int i=0;i<this->row;i++)
	{
		for(int j=0;j<this->col;j++)
		{
			this->array[i]=this->array[i]+x;
		}
	}
	return *this;
}

int Matrix::SetValue(int &r,int &c,int value)
{
	array[r][c] = value;
};

int Matrix::operator()(int &r,int &c,int value)const
{
	array[r][c] = value;
};


int Matrix::getValue(int r,int c)
{
	return array[r][c];
}

bool Matrix::operator==(const Matrix &m)
{
	if(this->row==m.row and this->col==m.col)
	{
		for(int i=0;i<row*col;i++)
		{
		    if(this->array!=m.array)
		    {
			return false;
		    }
		}
		return true;
	}
	else 
	return false;
}

ostream& operator<<(ostream& out,const Matrix& m1) 
{ 
   for(int i=0;i<m1.row;i++)
   {
	for(int j=0;j<m1.col;j++)
	{
		out<<m1.array[i][j];
	}
	out<<endl;
    }
 	return out;
} 

istream& operator>>(istream& in,const Matrix& m1) 
{ 
   for(int i=0;i<m1.row;i++)
   {
	for(int j=0;j<m1.col;j++)
	{
		in>>m1.array[i][j];
	}
    }
 	return in;
} 


Matrix::~Matrix()
{ 
	   delete[] array; 
}
