#include <iostream>
#include "q3.h"
#include <cmath>



using namespace std;

int main()
{
	int r = 4;
	int c = 4;
	Matrix MatrixA(r,c);
	Matrix MatrixB(r,c);
	Matrix MatrixC(r,c);

	/*for (int i=0; i<r; i++)
	{
		for (int j=0; j<c; j++)
		{
			MatrixA.setValue(i,j,3);
			MatrixB.setValue(i,j,4);
		}
	}*/

	cout << "MatrixA" << endl;
	for (int i=0; i<r; i++)
	{
		for (int j=0; j<c; j++)
		{
			cout<<MatrixA.getValue(i,j)<<"        ";
		}
		cout<<endl;
	}
	cout<<endl;

	cout << "MatrixB" << endl;
	for (int i=0; i<r; i++)
	{
		for (int j=0; j<c; j++)
		{
			cout << MatrixB.getValue(i,j) << "        ";
		}
		cout << endl;
	}
	cout << endl;

	cout << "MatrixC before addition" << endl;
	for (int i=0; i<r; i++)
	{
		for (int j=0; j<c; j++)
		{
			cout << MatrixC.getValue(i,j) << "        ";
		}
		cout << endl;
	}
	cout << endl;

	MatrixC=MatrixA+MatrixB;

	cout << "MatrixC after Addition" << endl;
	for (int i=0; i<r; i++)
	{
		for (int j=0; j<c; j++)
		{
			cout << MatrixC.getValue(i,j) << "        ";
		}
		cout << endl;
	}
	cout << endl;
}
















