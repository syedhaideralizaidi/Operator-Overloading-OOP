#include "string.h"
#include <string>
#include "string"
#include <cstring>
#include <iostream>
using namespace std;

String::String() 
{
	str_size = 0;
	Mystr = nullptr;
}

String::String(char*str)					
{
	str_size=strlen(str);
	Mystr=new char[str_size+1];
	strcpy(Mystr,str);
}

String::String(const String &str)
{
	str_size=str.str_size;
	Mystr=new char[str_size+1];
	strcpy(Mystr,str.Mystr);
}

String::String(int x)
{
	str_size = x;
	Mystr = new char[str_size];
}

char& String::operator[](int i)
{
	return Mystr[i];
}

char& String::operator[](int i)const
{
	return Mystr[i];
}

String& String::operator+(const String &str)
{
	String obj;
	obj.str_size=this->str_size+str.str_size;
	obj.Mystr=new char[obj.str_size+1];
	
	strcpy(obj.Mystr,this->Mystr);
	strcat(obj.Mystr,str.Mystr);
	return obj;
}


bool String::operator!()
{
	 for(int i=0;i<str_size;i++)
	 {
		if(Mystr[i]==0)
		return true;
		else
		return false;
	 }
}


String& String::operator=(const String& S1)
{
	str_size=S1.str_size;
	Mystr = new char[str_size];
	for (int i=0;i<str_size; i++)
	{
		Mystr[i] = S1.Mystr[i];
	}
	return *this;
	
}

bool String::operator==(const String& S1)const				
{
	if (str_size!= S1.str_size)
		return false;
	for (int i=0;i<str_size;i++)
	{
		if (Mystr[i] != S1.Mystr[i])
		{
			return false;
		}
	}
	return true;
}


int String::operator()(char find)				
{
	int i=0;
	for (i=0;i<str_size;i++)
	{
	    if (Mystr[i]==find)
		{
			break;
		}
	}
	int &val=i;
	return val;
}


int String::length()						
{
	return strlen(Mystr);
}

String::~String() 
{
	delete[]Mystr;
}


ostream& operator<<(ostream& out, const String &s)
{
	out<<"Entered string is \n"<<s.Mystr<<endl;
	return out;
}

istream& operator>>(istream& in,String &s)
{
	char Mystr[25];
	cout<<"Enter the string: "<<endl;
	in>>Mystr;
	
	s.str_size=strlen(Mystr);
	s.Mystr=new char[s.str_size+1];
	strcpy(s.Mystr,Mystr);
	return in;
}
