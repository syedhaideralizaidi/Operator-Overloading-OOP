#ifndef INCLUDE_Q2_H
#define INCLUDE_Q2_H
#include <string>
#include <cstring>
#include <iostream>
using namespace std;

class String
{

	private:
		char *Mystr;
		int str_size;

	public:
		String();
		String(char*str);
		String(const String &);
		String(int x);

		char&operator[](int i);
		char&operator[](int i)const;

		String& operator+(const String &str);
		String& operator+(const char&str);
		String& operator+(char*&str);
		
		String& operator-(const String &substr);

		bool operator!();

		String& operator=(const String&);
		String& operator=(char*);
		String& operator=(const string&);

		bool operator==(const String&)const;
		bool operator==(const string&)const;
		bool operator==(char *)const;

		int operator()(char);
		int operator()(const String&);
		int operator()(const string&);
		int operator()(char *);

		String operator*(int a);
		int length();
		~String();
		friend ostream& operator<<(ostream& input, const String&);
		friend istream& operator>>(istream& output, String&); 

};


#endif

