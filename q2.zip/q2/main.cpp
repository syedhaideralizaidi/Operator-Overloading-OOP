#include "q2.h"
#include <iostream>
using namespace std;

int main()
{
     String a("Zaidi");
     String b("Ali");
     String c;


	c=a+b;
	cout<<c;

	a=b;
	cout<<a;
	
	cout<<"Finding a character"<<endl;	
	cout<<a(a);

	c=b-a;
	cout<<c;
	
	cout<<"Enter the string for c"<<endl;
	cin>>c;

	cout<<a[3]<<endl;

	return 0;

}
